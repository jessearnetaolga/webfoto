<?php
$hostname ='localhost';
$userdb = 'root';
$passdb = '';
$namedb = 'webfoto';

$koneksi = mysqli_connect($hostname,$userdb,$passdb,$namedb);

?>