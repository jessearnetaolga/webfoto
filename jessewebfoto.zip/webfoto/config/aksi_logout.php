<?php
session_start();
session_destroy();
echo "<script>alert('berhasil');
location.href='../index.php';
</script>";